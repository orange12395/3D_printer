Arduino library for Trinamic TMC stepper motor drivers.

Supported TMC drivers:
* TMC2130
* TMC2160
* TMC2208
* TMC2209
* TMC2224
* TMC2660
* TMC5130
* TMC5160
* TMC5161